=== Create Custom Hover Effects On Images WP Plugins ===
Contributors: William Stancil
Donate link: https://trendbydesigns.com/contact/
Tags: Create Custom Hover Effects On Images WP Plugins,Hover Effects On Images
Requires at least: 3.3
Tested up to: 4.9.5
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

Create Custom Hover Effects On Images WP Plugins   is a jQuery plugin for manipulating images that makes it easier to apply custom hover effects (e.g. overlay, slide, zoom in/out, CSS filters) to images.

== Installation ==


1. Upload `Create Custom Hover Effects On Images WP Plugins`  floder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3.Use shortcode in page, post or in widgets. short code is [ccheoi]
3.If you want Date and Time in your template php file , Place `<?php echo do_shortcode('ccheoi'); ?>` in your templates

Shortcodes Is [ccheoi]

== Frequently asked questions ==

= Do you get any problem to Install or use this plugins?
 
Answer: please contact with me ,i will fix all issue .My mail: trendbydesigns@gmail.com , you can also visite : https://trendbydesigns.com/contact/

== Screenshots ==



== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==

